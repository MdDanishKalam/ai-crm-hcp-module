
# AI-First CRM – HCP Module (Top 1% Submission)

## 🚀 Highlights
- Dual Input: Chat + Structured Form
- AI Agent (LangGraph-ready architecture)
- 5 Intelligent Tools:
  - Log Interaction
  - Edit Interaction
  - Retrieve History
  - Summarize Interaction
  - Suggest Next Action
- LLM-ready (Groq integration placeholder)
- Confidence scoring included

## 🧠 AI Flow
User Input → Agent Routing → Tool Execution → Structured Output

## ⚙️ Setup

### Backend
cd backend
pip install -r requirements.txt
uvicorn main:app --reload

### Frontend
cd frontend
npm install
npm start

## 🎥 Demo Tips
- Show chat → structured output
- Show tool switching
- Highlight AI suggestions
- Explain agent decision-making

## 🔥 Upgrade Hooks
- Plug Groq API in llm_service.py
- Add PostgreSQL via SQLAlchemy
- Replace routing with real LangGraph StateGraph
