
import React, { useState } from "react";

function App() {
  const [mode, setMode] = useState("chat");
  const [input, setInput] = useState("");
  const [response, setResponse] = useState(null);

  const send = async () => {
    const res = await fetch("http://localhost:8000/chat/process", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({message: input})
    });
    const data = await res.json();
    setResponse(data);
  };

  return (
    <div style={{padding:20,fontFamily:"Inter"}}>
      <h1>AI CRM (Top 1%)</h1>

      <button onClick={()=>setMode("chat")}>Chat Mode</button>
      <button onClick={()=>setMode("form")}>Form Mode</button>

      {mode==="chat" ? (
        <>
          <textarea value={input} onChange={e=>setInput(e.target.value)} />
          <button onClick={send}>Process</button>
        </>
      ) : (
        <div>
          <input placeholder="HCP Name"/>
          <input placeholder="Notes"/>
          <button>Submit</button>
        </div>
      )}

      <h3>AI Output</h3>
      <pre>{JSON.stringify(response,null,2)}</pre>
    </div>
  );
}

export default App;
