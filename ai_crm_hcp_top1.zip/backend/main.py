
from fastapi import FastAPI
from pydantic import BaseModel
from agents.langgraph_flow import run_agent

app = FastAPI()

class ChatInput(BaseModel):
    message: str

@app.get("/")
def root():
    return {"status": "Top 1% AI CRM HCP Module Running"}

@app.post("/chat/process")
def process_chat(input: ChatInput):
    return run_agent(input.message)
