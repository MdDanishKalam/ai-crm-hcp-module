
# Plug your Groq API here

def extract_entities(text):
    # Replace with Groq call
    return {
        "hcp_name": "Dr. Sharma",
        "sentiment": "neutral",
        "summary": text[:100]
    }
