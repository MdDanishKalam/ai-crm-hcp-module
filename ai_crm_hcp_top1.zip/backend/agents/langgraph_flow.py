
# Simulated LangGraph-style flow (structured for easy upgrade to real graph)

from tools.log_tool import log_interaction
from tools.edit_tool import edit_interaction
from tools.retrieve_tool import retrieve_interaction
from tools.suggest_tool import suggest_next
from tools.summarize_tool import summarize_interaction

def run_agent(message):
    msg = message.lower()

    if "update" in msg or "edit" in msg:
        return edit_interaction(message)

    if "history" in msg or "past" in msg:
        return retrieve_interaction(message)

    if "suggest" in msg or "next" in msg:
        return suggest_next(message)

    if "summary" in msg:
        return summarize_interaction(message)

    return log_interaction(message)
