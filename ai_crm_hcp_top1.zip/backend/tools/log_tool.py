
from services.llm_service import extract_entities

def log_interaction(message):
    data = extract_entities(message)
    return {
        "tool": "log_interaction",
        "confidence": 0.92,
        "structured": data
    }
