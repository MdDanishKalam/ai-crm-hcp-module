
def suggest_next(message):
    return {
        "tool": "suggest",
        "next_action": "Schedule follow-up in 2 weeks"
    }
