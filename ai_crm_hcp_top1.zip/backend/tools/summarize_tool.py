
def summarize_interaction(message):
    return {
        "tool": "summarize",
        "summary": "Doctor showed interest but needs more data."
    }
